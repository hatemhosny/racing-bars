import os

dirname = os.path.dirname(__file__)

JS_LIB = dirname + "/static/racing-bars.umd.js"
TEMPLATE = dirname + "/static/template.html"
TEMPLATE_PLACEHOLDER = "racingbars"
ID_PREFIX = "racingbars"
DATA_DIR = dirname + "/data/"
