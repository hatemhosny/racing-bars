# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['racingbars']

package_data = \
{'': ['*'], 'racingbars': ['data/*', 'static/*']}

install_requires = \
['ipython>=7.15.0,<8.0.0', 'pandas>=1.0.4,<2.0.0']

setup_kwargs = {
    'name': 'racingbars',
    'version': '0.0.0',
    'description': 'Bar chart race, easy to use, based on d3',
    'long_description': '',
    'author': 'Hatem Hosny',
    'author_email': 'hatemhosny@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
