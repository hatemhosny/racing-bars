__version__ = '0.0.0'

from .write_html import write_html


__all__ = [write_html]

